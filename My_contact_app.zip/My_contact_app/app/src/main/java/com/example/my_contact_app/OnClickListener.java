package com.example.my_contact_app;

public interface OnClickListener {
    void onclick(long id,String name,String number);
}
