package com.example.my_contact_app;

public interface OnchangeListener {
    void onChange();
}
